<?php

$conn = mysqli_connect('localhost', 'root', '', 'my_db');


if(!$conn){
    die("Something went wrong");
}

?>