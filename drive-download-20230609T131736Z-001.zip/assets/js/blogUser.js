const logo = document.getElementById("logo");
logo.addEventListener('click' , function() {
    window.location.href = "index.php"
})